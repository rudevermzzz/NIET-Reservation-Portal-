import React, { useState, useMemo } from 'react';
import { 
  Building, 
  Users, 
  Clock, 
  Check, 
  X, 
  HelpCircle, 
  FileSpreadsheet, 
  Download, 
  Database, 
  Search, 
  RefreshCw, 
  ShieldCheck, 
  Activity, 
  FileText, 
  Calendar as CalendarIcon, 
  ChevronRight, 
  Sparkles,
  Lock,
  Unlock,
  Trash2,
  AlertCircle,
  Filter,
  CheckCircle2,
  AlertTriangle,
  User,
  Mail,
  UserCheck
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Booking, ApprovalRequest, Persona, SystemLog, RoomConfig } from '../types';

interface AdminConsoleProps {
  requests: ApprovalRequest[];
  bookings: Booking[];
  personas: Persona[];
  rooms: RoomConfig[];
  timeSlots: string[];
  systemLogs: SystemLog[];
  isLiveSyncing: boolean;
  lastSyncTime: Date;
  onApproveRequest: (id: string) => void;
  onRejectRequest: (id: string) => void;
  onQueryRequest: (id: string) => void;
  onReplyToQuery: (id: string, reply: string) => void;
  onDeleteRequest: (id: string) => void;
  onDeleteBooking: (bookingId: string) => void;
  onDownloadExcel: (filtered?: ApprovalRequest[]) => void;
  onDownloadCsv: () => void;
  onResetMemberPin: (name: string) => void;
  onRemoveMember: (name: string) => void;
  onExitAdmin: () => void;
  triggerToast: (msg: string, type: 'success' | 'error' | 'info') => void;
}

export const AdminConsole: React.FC<AdminConsoleProps> = ({
  requests,
  bookings,
  personas,
  rooms,
  timeSlots,
  systemLogs,
  isLiveSyncing,
  lastSyncTime,
  onApproveRequest,
  onRejectRequest,
  onQueryRequest,
  onReplyToQuery,
  onDeleteRequest,
  onDeleteBooking,
  onDownloadExcel,
  onDownloadCsv,
  onResetMemberPin,
  onRemoveMember,
  onExitAdmin,
  triggerToast
}) => {
  const [adminSubTab, setAdminSubTab] = useState<'triage' | 'excel-hub' | 'master-timetable' | 'members-directory' | 'audit-log'>('triage');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Pending' | 'Queried' | 'Approved' | 'Rejected'>('All');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [excelSheetTab, setExcelSheetTab] = useState<'requests' | 'bookings' | 'members' | 'summary'>('requests');
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    const d = new Date();
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  });

  // Metrics
  const pendingRequests = useMemo(() => requests.filter(r => r.status === 'Pending'), [requests]);
  const queriedRequests = useMemo(() => requests.filter(r => r.status === 'Queried'), [requests]);
  const approvedRequests = useMemo(() => requests.filter(r => r.status === 'Approved'), [requests]);
  const rejectedRequests = useMemo(() => requests.filter(r => r.status === 'Rejected'), [requests]);

  // Filtered requests for triage
  const filteredTriageRequests = useMemo(() => {
    return requests.filter(req => {
      if (statusFilter !== 'All' && req.status !== statusFilter) return false;
      if (searchTerm.trim()) {
        const query = searchTerm.toLowerCase();
        const matchesName = req.requesterName.toLowerCase().includes(query);
        const matchesRoom = req.room.toLowerCase().includes(query);
        const matchesRole = req.role.toLowerCase().includes(query);
        const matchesPurpose = req.purpose.toLowerCase().includes(query);
        if (!matchesName && !matchesRoom && !matchesRole && !matchesPurpose) return false;
      }
      return true;
    });
  }, [requests, statusFilter, searchTerm]);

  return (
    <div className="flex-1 flex flex-col min-h-screen bg-slate-50 text-slate-800 font-sans" id="executive-admin-console">
      {/* Top Executive Operations Header - Matching Main Theme */}
      <header className="bg-white border-b border-slate-200 px-4 md:px-8 py-3.5 sticky top-0 z-30 shadow-xs backdrop-blur-md flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-gradient-to-tr from-red-600 to-rose-500 rounded-xl shadow-md shadow-red-600/20 text-white flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm md:text-base font-extrabold tracking-tight text-slate-900 font-display">
                  NIET TBI Executive Operations Center
                </h1>
                <span className="bg-red-50 border border-red-200 text-red-700 text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider">
                  Superuser
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium flex items-center gap-1.5">
                <span>Master Reservation &amp; Excel Control Console</span>
                <span className="text-slate-300">&bull;</span>
                <span className="text-emerald-700 font-mono flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  Real-Time Synced (1.5s)
                </span>
              </p>
            </div>
          </div>
        </div>

        {/* Header Right Action Controls */}
        <div className="flex items-center gap-2 w-full md:w-auto justify-between md:justify-end flex-wrap">
          {/* Quick Excel Export */}
          <button
            onClick={() => onDownloadExcel()}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer"
            title="Download Master Excel Workbook (.xlsx)"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Export Excel (.xlsx)</span>
          </button>

          {/* Quick CSV Export */}
          <button
            onClick={() => onDownloadCsv()}
            className="flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-slate-50 active:scale-95 text-slate-700 rounded-xl text-xs font-bold transition-all border border-slate-200 shadow-xs cursor-pointer"
            title="Download CSV"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span className="hidden sm:inline">CSV</span>
          </button>

          {/* Exit Admin Mode */}
          <button
            onClick={onExitAdmin}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-rose-50 text-slate-700 hover:text-rose-700 border border-slate-200 hover:border-rose-200 rounded-xl text-xs font-bold transition-all cursor-pointer"
            title="Lock Superuser Console & Exit to Booker Workspace"
          >
            <Lock className="w-3.5 h-3.5 text-slate-500" />
            <span>Exit Admin</span>
          </button>
        </div>
      </header>

      {/* Admin Navigation Bar - Matching Main Theme */}
      <nav className="bg-white border-b border-slate-200 px-4 md:px-8 py-2 flex items-center gap-1.5 overflow-x-auto shadow-xs">
        <button
          onClick={() => setAdminSubTab('triage')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            adminSubTab === 'triage'
              ? 'bg-red-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Activity className="w-3.5 h-3.5" />
          <span>Approval &amp; Triage Queue</span>
          {pendingRequests.length > 0 && (
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-black ${
              adminSubTab === 'triage' ? 'bg-white text-red-700' : 'bg-amber-100 text-amber-800'
            }`}>
              {pendingRequests.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setAdminSubTab('excel-hub')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            adminSubTab === 'excel-hub'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <FileSpreadsheet className="w-3.5 h-3.5" />
          <span>Excel Master Ledger Hub</span>
          <span className={`text-[9px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
            adminSubTab === 'excel-hub' ? 'bg-white text-emerald-800' : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
          }`}>
            {requests.length} rows
          </span>
        </button>

        <button
          onClick={() => setAdminSubTab('master-timetable')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            adminSubTab === 'master-timetable'
              ? 'bg-red-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <CalendarIcon className="w-3.5 h-3.5" />
          <span>Master Room Timetable</span>
        </button>

        <button
          onClick={() => setAdminSubTab('members-directory')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            adminSubTab === 'members-directory'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>TBI Member Directory</span>
          <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
            adminSubTab === 'members-directory' ? 'bg-white text-indigo-800' : 'bg-slate-100 text-slate-700'
          }`}>
            {personas.length}
          </span>
        </button>

        <button
          onClick={() => setAdminSubTab('audit-log')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
            adminSubTab === 'audit-log'
              ? 'bg-slate-800 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Real-Time Audit Trail</span>
        </button>
      </nav>

      {/* Main Body Content */}
      <main className="flex-1 p-4 md:p-8 overflow-y-auto max-w-7xl mx-auto w-full">
        {/* ======================================================== */}
        {/* 1. APPROVAL & TRIAGE QUEUE SUB-TAB                       */}
        {/* ======================================================== */}
        {adminSubTab === 'triage' && (
          <div className="space-y-6">
            {/* Top Stat Ribbon */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
              <div className="bg-white border border-slate-200/90 p-4 rounded-2xl shadow-xs">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                  Pending Authorization
                </span>
                <span className="text-2xl md:text-3xl font-black text-amber-600 font-display mt-0.5 block">
                  {pendingRequests.length}
                </span>
                <span className="text-[10px] text-amber-700 font-semibold">Awaiting Superuser review</span>
              </div>

              <div className="bg-white border border-slate-200/90 p-4 rounded-2xl shadow-xs">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                  Queried Requests
                </span>
                <span className="text-2xl md:text-3xl font-black text-purple-600 font-display mt-0.5 block">
                  {queriedRequests.length}
                </span>
                <span className="text-[10px] text-purple-700 font-semibold">Awaiting member reply</span>
              </div>

              <div className="bg-white border border-slate-200/90 p-4 rounded-2xl shadow-xs">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                  Active Bookings On Grid
                </span>
                <span className="text-2xl md:text-3xl font-black text-emerald-600 font-display mt-0.5 block">
                  {bookings.length}
                </span>
                <span className="text-[10px] text-emerald-700 font-semibold">Occupying slots</span>
              </div>

              <div className="bg-white border border-slate-200/90 p-4 rounded-2xl shadow-xs">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                  Registered Members
                </span>
                <span className="text-2xl md:text-3xl font-black text-indigo-600 font-display mt-0.5 block">
                  {personas.length}
                </span>
                <span className="text-[10px] text-indigo-700 font-semibold">In TBI Directory</span>
              </div>
            </div>

            {/* Filter and Search Bar */}
            <div className="bg-white border border-slate-200 p-4 rounded-2xl shadow-xs flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              {/* Search */}
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search by requester, role, room, or purpose..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 transition-all"
                />
              </div>

              {/* Status Filter Tabs */}
              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200 overflow-x-auto">
                {(['All', 'Pending', 'Queried', 'Approved', 'Rejected'] as const).map((st) => (
                  <button
                    key={st}
                    onClick={() => setStatusFilter(st)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                      statusFilter === st
                        ? 'bg-red-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {st} ({requests.filter(r => st === 'All' || r.status === st).length})
                  </button>
                ))}
              </div>
            </div>

            {/* Request Cards Grid */}
            {filteredTriageRequests.length === 0 ? (
              <div className="bg-white border border-dashed border-slate-300 rounded-3xl p-12 text-center shadow-xs">
                <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
                <h3 className="text-base font-bold text-slate-800">No requests match the selected criteria</h3>
                <p className="text-xs text-slate-500 mt-1">All queues are up to date and synchronized with Excel.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <AnimatePresence>
                  {filteredTriageRequests.map((req) => (
                    <motion.div
                      key={req.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      className={`bg-white border rounded-2xl p-5 shadow-xs flex flex-col justify-between transition-all hover:shadow-md ${
                        req.status === 'Pending' ? 'border-amber-300 ring-1 ring-amber-200/50' :
                        req.status === 'Queried' ? 'border-purple-300 ring-1 ring-purple-200/50' :
                        req.status === 'Approved' ? 'border-emerald-200' :
                        'border-rose-200'
                      }`}
                    >
                      <div>
                        {/* Header of Card */}
                        <div className="flex items-start justify-between gap-3 mb-3">
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="text-sm font-extrabold text-slate-900">{req.requesterName}</h4>
                              <span className="text-[10px] font-bold text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded-full uppercase tracking-wider">
                                {req.role}
                              </span>
                            </div>
                            {req.email && (
                              <p className="text-[11px] text-slate-500 font-mono mt-0.5 flex items-center gap-1">
                                <Mail className="w-3 h-3 text-slate-400" />
                                {req.email}
                              </p>
                            )}
                          </div>

                          <span className={`text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider ${
                            req.status === 'Pending' ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                            req.status === 'Queried' ? 'bg-purple-50 text-purple-700 border border-purple-200' :
                            req.status === 'Approved' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                            'bg-rose-50 text-rose-700 border border-rose-200'
                          }`}>
                            {req.status}
                          </span>
                        </div>

                        {/* Booking Details Pill */}
                        <div className="bg-slate-50 border border-slate-100 rounded-xl p-3.5 mb-3 space-y-1.5">
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-slate-500 font-semibold">Incubator Space:</span>
                            <span className="font-bold text-slate-900">{req.room}</span>
                          </div>
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-slate-500 font-semibold">Date &amp; Time Slot:</span>
                            <span className="font-bold text-red-600 font-mono">
                              {req.date} &bull; {Array.isArray(req.slots) ? req.slots.join(', ') : req.slots}
                            </span>
                          </div>
                          <div className="flex items-center justify-between text-[11px] text-slate-400">
                            <span>Logged In Excel:</span>
                            <span>{new Date(req.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                          </div>
                        </div>

                        {/* Purpose Justification */}
                        <div className="bg-slate-50/70 border border-slate-100 p-3 rounded-xl mb-3 text-xs text-slate-700">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                            Purpose Justification
                          </span>
                          <p className="italic leading-relaxed">&ldquo;{req.purpose}&rdquo;</p>
                        </div>

                        {/* Query Message if present */}
                        {req.status === 'Queried' && req.queryMessage && (
                          <div className="bg-purple-50 border border-purple-200 p-3 rounded-xl mb-3 text-xs">
                            <span className="text-[10px] font-bold text-purple-700 uppercase tracking-wider block mb-1">
                              Admin Clarification Note
                            </span>
                            <p className="text-purple-900 italic">&ldquo;{req.queryMessage}&rdquo;</p>
                          </div>
                        )}
                      </div>

                      {/* Action Buttons */}
                      <div className="pt-3 border-t border-slate-100 flex items-center gap-2">
                        {req.status === 'Pending' || req.status === 'Queried' ? (
                          <>
                            <button
                              onClick={() => onApproveRequest(req.id)}
                              className="flex-1 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white py-2 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center justify-center gap-1.5"
                            >
                              <Check className="w-3.5 h-3.5" />
                              <span>Authorize &amp; Book</span>
                            </button>

                            <button
                              onClick={() => onQueryRequest(req.id)}
                              className="flex-1 bg-purple-50 hover:bg-purple-100 border border-purple-200 text-purple-700 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5"
                            >
                              <HelpCircle className="w-3.5 h-3.5" />
                              <span>{req.status === 'Queried' ? 'Re-Query' : 'Query Member'}</span>
                            </button>

                            <button
                              onClick={() => onRejectRequest(req.id)}
                              className="px-3 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center"
                              title="Reject Request"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </>
                        ) : (
                          <div className="w-full flex justify-between items-center">
                            <span className="text-xs text-slate-400 font-semibold">
                              Archived in Excel Ledger
                            </span>
                            <button
                              onClick={() => onDeleteRequest(req.id)}
                              className="text-xs text-slate-400 hover:text-rose-600 p-1.5 rounded-lg hover:bg-rose-50 transition-colors cursor-pointer"
                              title="Delete Record from List"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </div>
        )}

        {/* ======================================================== */}
        {/* 2. EXCEL MASTER LEDGER HUB SUB-TAB                       */}
        {/* ======================================================== */}
        {adminSubTab === 'excel-hub' && (
          <div className="space-y-6">
            {/* Top Download & Ledger Info Banner */}
            <div className="bg-gradient-to-r from-emerald-50 via-white to-slate-50 border border-emerald-200 p-6 rounded-2xl shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-emerald-100 text-emerald-800 rounded-xl">
                    <FileSpreadsheet className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-base font-extrabold text-slate-900 tracking-tight font-display">
                      NIET TBI Master Excel Ledger
                    </h3>
                    <p className="text-xs text-slate-600 font-medium">
                      All booking reservations, dates, times, roles, and member emails are automatically archived in real time.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2.5 flex-wrap w-full md:w-auto">
                <button
                  onClick={() => onDownloadExcel()}
                  className="flex-1 md:flex-none bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold px-4 py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 shadow-xs cursor-pointer transition-all"
                >
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>Download Workbook (.xlsx)</span>
                </button>
                <button
                  onClick={() => onDownloadCsv()}
                  className="flex-1 md:flex-none bg-white hover:bg-slate-50 text-slate-700 font-bold px-4 py-2.5 rounded-xl text-xs flex items-center justify-center gap-1.5 border border-slate-200 shadow-xs cursor-pointer transition-all"
                >
                  <Download className="w-4 h-4 text-slate-500" />
                  <span>Download CSV</span>
                </button>
              </div>
            </div>

            {/* Sheet Selector Tabs */}
            <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
              <button
                onClick={() => setExcelSheetTab('requests')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  excelSheetTab === 'requests'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                Sheet 1: Requests Ledger ({requests.length})
              </button>
              <button
                onClick={() => setExcelSheetTab('bookings')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  excelSheetTab === 'bookings'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                Sheet 2: Confirmed Schedule ({bookings.length})
              </button>
              <button
                onClick={() => setExcelSheetTab('members')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  excelSheetTab === 'members'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                Sheet 3: Registered Personas ({personas.length})
              </button>
            </div>

            {/* Live Interactive Excel Sheet Table Preview */}
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
              <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <Database className="w-4 h-4 text-emerald-600" />
                  <span className="text-xs font-extrabold text-slate-800 uppercase tracking-wider">
                    {excelSheetTab === 'requests' && 'Requests Master Sheet'}
                    {excelSheetTab === 'bookings' && 'Confirmed Reservations Sheet'}
                    {excelSheetTab === 'members' && 'Registered Members Sheet'}
                  </span>
                </div>
                <span className="text-[10px] font-mono text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  Disk Path: /data/NIET_TBI_Booking_Ledger.xlsx
                </span>
              </div>

              <div className="overflow-x-auto max-h-[500px]">
                {excelSheetTab === 'requests' && (
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-600 uppercase text-[9px] font-black tracking-wider sticky top-0 border-b border-slate-200">
                      <tr>
                        <th className="p-3.5">Timestamp</th>
                        <th className="p-3.5">Requester Name</th>
                        <th className="p-3.5">Role</th>
                        <th className="p-3.5">Email</th>
                        <th className="p-3.5">Room</th>
                        <th className="p-3.5">Date</th>
                        <th className="p-3.5">Slots</th>
                        <th className="p-3.5">Purpose</th>
                        <th className="p-3.5">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      {requests.map((r) => (
                        <tr key={r.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="p-3.5 font-mono text-[10px] text-slate-500 whitespace-nowrap">
                            {new Date(r.timestamp).toLocaleString("en-IN", { timeZone: "Asia/Kolkata", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                          </td>
                          <td className="p-3.5 font-bold text-slate-900 whitespace-nowrap">{r.requesterName}</td>
                          <td className="p-3.5 text-[10px] text-indigo-700 font-semibold whitespace-nowrap">{r.role}</td>
                          <td className="p-3.5 text-slate-500 font-mono text-[10px] whitespace-nowrap">{r.email || 'N/A'}</td>
                          <td className="p-3.5 font-bold text-slate-800 whitespace-nowrap">{r.room}</td>
                          <td className="p-3.5 font-mono text-slate-700 whitespace-nowrap">{r.date}</td>
                          <td className="p-3.5 text-slate-700 whitespace-nowrap">{Array.isArray(r.slots) ? r.slots.join(', ') : r.slots}</td>
                          <td className="p-3.5 max-w-[200px] truncate" title={r.purpose}>{r.purpose}</td>
                          <td className="p-3.5 whitespace-nowrap">
                            <span className={`text-[9px] font-extrabold px-2 py-0.5 rounded-full ${
                              r.status === 'Approved' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                              r.status === 'Pending' ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                              r.status === 'Queried' ? 'bg-purple-50 text-purple-700 border border-purple-200' :
                              'bg-rose-50 text-rose-700 border border-rose-200'
                            }`}>
                              {r.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}

                {excelSheetTab === 'bookings' && (
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-600 uppercase text-[9px] font-black tracking-wider sticky top-0 border-b border-slate-200">
                      <tr>
                        <th className="p-3.5">ID</th>
                        <th className="p-3.5">Room</th>
                        <th className="p-3.5">Title</th>
                        <th className="p-3.5">Organizer</th>
                        <th className="p-3.5">Role</th>
                        <th className="p-3.5">Date</th>
                        <th className="p-3.5">Time Slots</th>
                        <th className="p-3.5">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      {bookings.map((b) => (
                        <tr key={b.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="p-3.5 font-mono text-[10px] text-slate-400">{b.id}</td>
                          <td className="p-3.5 font-bold text-slate-900">{b.room}</td>
                          <td className="p-3.5 font-medium">{b.title}</td>
                          <td className="p-3.5 font-bold text-slate-800">{b.organizer}</td>
                          <td className="p-3.5 text-indigo-700 font-semibold">{b.role}</td>
                          <td className="p-3.5 font-mono text-slate-600">{b.date}</td>
                          <td className="p-3.5">{b.slots.join(', ')}</td>
                          <td className="p-3.5">
                            <button
                              onClick={() => onDeleteBooking(b.id)}
                              className="text-rose-600 hover:text-rose-800 p-1 rounded hover:bg-rose-50 transition-colors cursor-pointer"
                              title="Revoke Booking"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}

                {excelSheetTab === 'members' && (
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-600 uppercase text-[9px] font-black tracking-wider sticky top-0 border-b border-slate-200">
                      <tr>
                        <th className="p-3.5">Member Name</th>
                        <th className="p-3.5">Role</th>
                        <th className="p-3.5">Email Address</th>
                        <th className="p-3.5">PIN Protection</th>
                        <th className="p-3.5">Total Bookings</th>
                        <th className="p-3.5">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      {personas.map((p) => {
                        const count = bookings.filter(b => b.organizer.toLowerCase() === p.name.toLowerCase()).length;
                        return (
                          <tr key={p.name} className="hover:bg-slate-50/80 transition-colors">
                            <td className="p-3.5 font-bold text-slate-900">{p.name}</td>
                            <td className="p-3.5 text-indigo-700 font-semibold">{p.role}</td>
                            <td className="p-3.5 text-slate-500 font-mono">{p.email}</td>
                            <td className="p-3.5">
                              {p.pin ? (
                                <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded text-[10px] font-bold">
                                  🔒 PIN Active
                                </span>
                              ) : (
                                <span className="text-slate-400 text-[10px]">No PIN set</span>
                              )}
                            </td>
                            <td className="p-3.5 font-bold text-slate-800">{count}</td>
                            <td className="p-3.5 flex items-center gap-2">
                              {p.pin && (
                                <button
                                  onClick={() => onResetMemberPin(p.name)}
                                  className="text-[10px] bg-slate-100 hover:bg-slate-200 text-slate-700 px-2 py-1 rounded transition-colors font-bold cursor-pointer"
                                >
                                  Reset PIN
                                </button>
                              )}
                              <button
                                onClick={() => onRemoveMember(p.name)}
                                className="text-rose-600 hover:text-rose-800 p-1 rounded hover:bg-rose-50 transition-colors cursor-pointer"
                                title="Remove Profile"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* 3. MASTER ROOM TIMETABLE SUB-TAB                         */}
        {/* ======================================================== */}
        {adminSubTab === 'master-timetable' && (
          <div className="space-y-6">
            <div className="bg-white border border-slate-200 p-4 rounded-2xl shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                  Incubator Space Grid Overrides
                </h3>
                <p className="text-xs text-slate-500">
                  Select a date to view current reservations or revoke occupied slots instantly.
                </p>
              </div>

              <div className="flex items-center gap-3">
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="bg-slate-50 border border-slate-200 text-slate-800 px-3 py-2 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-red-500/20"
                />
              </div>
            </div>

            {/* Matrix Table */}
            <div className="bg-white border border-slate-200 rounded-2xl overflow-x-auto shadow-xs">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 uppercase text-[9px] font-black tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="p-4 w-48">Incubator Space</th>
                    {timeSlots.map((slot) => (
                      <th key={slot} className="p-4 text-center">{slot}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {rooms.map((room) => (
                    <tr key={room.id} className="hover:bg-slate-50/50">
                      <td className="p-4 font-bold text-slate-900">
                        <p>{room.name}</p>
                        <span className="text-[10px] text-slate-500 font-normal">{room.location}</span>
                      </td>
                      {timeSlots.map((slot) => {
                        const booking = bookings.find(b => b.room === room.name && b.date === selectedDate && b.slots.includes(slot));
                        return (
                          <td key={slot} className="p-2 text-center">
                            {booking ? (
                              <div className="bg-red-50 border border-red-200 p-2 rounded-xl text-left">
                                <p className="text-xs font-bold text-red-950 truncate">{booking.organizer}</p>
                                <p className="text-[9px] text-red-700 font-semibold">{booking.role}</p>
                                <button
                                  onClick={() => onDeleteBooking(booking.id)}
                                  className="mt-1.5 w-full bg-rose-600 hover:bg-rose-700 text-white py-1 rounded text-[9px] font-bold transition-all cursor-pointer flex items-center justify-center gap-1 shadow-xs"
                                >
                                  <X className="w-3 h-3" /> Revoke
                                </button>
                              </div>
                            ) : (
                              <span className="text-[10px] text-slate-400 font-mono">Available</span>
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* 4. MEMBERS DIRECTORY SUB-TAB                             */}
        {/* ======================================================== */}
        {adminSubTab === 'members-directory' && (
          <div className="space-y-6">
            <div className="bg-white border border-slate-200 p-4 rounded-2xl shadow-xs flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                  Registered Incubator Personas &amp; Roles
                </h3>
                <p className="text-xs text-slate-500">
                  Manage member PINs, access profiles, and reservation privileges.
                </p>
              </div>
              <span className="bg-indigo-50 text-indigo-700 border border-indigo-200 px-3 py-1 rounded-xl text-xs font-black font-mono">
                {personas.length} Registered
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {personas.map((p) => {
                const memberBookings = bookings.filter(b => b.organizer.toLowerCase() === p.name.toLowerCase());
                const memberRequests = requests.filter(r => r.requesterName.toLowerCase() === p.name.toLowerCase());
                return (
                  <div key={p.name} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs flex flex-col justify-between hover:shadow-md transition-all">
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div>
                          <h4 className="text-sm font-extrabold text-slate-900">{p.name}</h4>
                          <span className="text-[10px] font-bold text-red-700 bg-red-50 border border-red-200 px-2 py-0.5 rounded uppercase mt-1 inline-block">
                            {p.role}
                          </span>
                        </div>
                        <div className="w-8 h-8 rounded-full bg-slate-100 text-slate-700 flex items-center justify-center font-black text-xs">
                          {p.name.split(' ').map(n => n[0]).join('').substring(0, 2)}
                        </div>
                      </div>

                      <p className="text-xs text-slate-500 font-mono mb-4">{p.email}</p>

                      <div className="grid grid-cols-2 gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-100 mb-4 text-center">
                        <div>
                          <p className="text-xs font-black text-slate-900">{memberBookings.length}</p>
                          <p className="text-[9px] text-slate-500 uppercase">Confirmed</p>
                        </div>
                        <div>
                          <p className="text-xs font-black text-slate-900">{memberRequests.length}</p>
                          <p className="text-[9px] text-slate-500 uppercase">Total Requests</p>
                        </div>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                      {p.pin ? (
                        <button
                          onClick={() => onResetMemberPin(p.name)}
                          className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1.5 rounded-xl transition-all font-bold cursor-pointer"
                        >
                          Reset PIN
                        </button>
                      ) : (
                        <span className="text-[10px] text-slate-400">No PIN lock</span>
                      )}

                      <button
                        onClick={() => onRemoveMember(p.name)}
                        className="text-xs text-rose-600 hover:text-rose-800 p-1.5 rounded-lg hover:bg-rose-50 transition-colors cursor-pointer"
                        title="Remove Member"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* 5. REAL-TIME AUDIT LOG SUB-TAB                           */}
        {/* ======================================================== */}
        {adminSubTab === 'audit-log' && (
          <div className="space-y-6">
            <div className="bg-white border border-slate-200 p-4 rounded-2xl shadow-xs flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                  Live System Audit Trail
                </h3>
                <p className="text-xs text-slate-500">
                  Chronological record of all reservation dispatches, superuser approvals, queries, and sync pulses.
                </p>
              </div>
              <span className="text-xs font-mono text-emerald-700 font-bold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                Broadcasting
              </span>
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl divide-y divide-slate-100 overflow-hidden shadow-xs">
              {systemLogs.map((log) => (
                <div key={log.id} className="p-3.5 flex items-center justify-between gap-3 text-xs hover:bg-slate-50 transition-colors">
                  <div className="flex items-center gap-2.5">
                    <span className={`w-2 h-2 rounded-full ${
                      log.type === 'success' ? 'bg-emerald-500' :
                      log.type === 'warning' ? 'bg-amber-500' :
                      log.type === 'error' ? 'bg-rose-500' : 'bg-indigo-500'
                    }`}></span>
                    <span className="text-slate-800 font-medium">{log.text}</span>
                  </div>
                  <span className="font-mono text-[10px] text-slate-400 whitespace-nowrap">{log.time}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
