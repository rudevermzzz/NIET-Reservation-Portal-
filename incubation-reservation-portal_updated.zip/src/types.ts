export interface Booking {
  id: string;
  room: string;
  title: string;
  organizer: string;
  role: string;
  date: string; // YYYY-MM-DD
  slots: string[]; // e.g. ["10:00 AM", "11:30 AM"]
  color: 'red' | 'amber' | 'emerald' | 'slate';
}

export interface ApprovalRequest {
  id: string;
  requesterName: string;
  role: string;
  email?: string;
  date: string; // YYYY-MM-DD
  room: string;
  slots: string[];
  purpose: string;
  status: 'Pending' | 'Approved' | 'Rejected' | 'Queried';
  timestamp: number;
  queryMessage?: string;
}

export interface Persona {
  name: string;
  role: string;
  email: string;
  pin?: string;
}

export interface SystemLog {
  id: string;
  text: string;
  time: string;
  type: 'info' | 'success' | 'warning' | 'error';
}

export interface RoomConfig {
  id: string;
  name: string;
  capacity: number;
  amenities: string[];
  location: string;
  color: 'red' | 'amber' | 'indigo' | 'emerald';
}
