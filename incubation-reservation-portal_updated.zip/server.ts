import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import nodemailer from "nodemailer";
import dotenv from "dotenv";
import * as XLSX from "xlsx";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "10mb" }));

  // File persistence helpers for multi-device sync
  const DATA_DIR = path.join(process.cwd(), "data");
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  const BOOKINGS_FILE = path.join(DATA_DIR, "bookings.json");
  const REQUESTS_FILE = path.join(DATA_DIR, "requests.json");
  const PERSONAS_FILE = path.join(DATA_DIR, "personas.json");
  const EXCEL_FILE = path.join(DATA_DIR, "NIET_TBI_Booking_Ledger.xlsx");

  function readJSONFile(filePath: string) {
    try {
      if (fs.existsSync(filePath)) {
        const content = fs.readFileSync(filePath, "utf-8");
        return JSON.parse(content);
      }
    } catch (err) {
      console.error(`Error reading ${filePath}:`, err);
    }
    return null;
  }

  function writeJSONFile(filePath: string, data: any) {
    try {
      fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf-8");
    } catch (err) {
      console.error(`Error writing ${filePath}:`, err);
    }
  }

  // Update or regenerate the Excel ledger workbook
  function updateExcelLedger() {
    try {
      const requests = readJSONFile(REQUESTS_FILE) || [];
      const bookings = readJSONFile(BOOKINGS_FILE) || [];
      const personas = readJSONFile(PERSONAS_FILE) || [];

      // Format Requests Sheet Data
      const requestsRows = requests.map((r: any) => {
        const submittedTime = r.timestamp 
          ? new Date(r.timestamp).toLocaleString("en-IN", { timeZone: "Asia/Kolkata" }) 
          : "N/A";
        const slotsStr = Array.isArray(r.slots) ? r.slots.join(", ") : (r.slots || "");
        return {
          "Request ID": r.id || "",
          "Submission Date & Time (IST)": submittedTime,
          "Requester Name": r.requesterName || "",
          "Role / Department": r.role || "",
          "Contact Email": r.email || "",
          "Space / Room": r.room || "",
          "Reservation Date": r.date || "",
          "Time Slot(s)": slotsStr,
          "Purpose / Justification": r.purpose || "",
          "Current Status": r.status || "Pending",
          "Admin Review Query/Notes": r.adminQuery || r.query || "",
          "Booker Clarification": r.requesterReply || "",
          "Amenities Requested": r.amenities ? (Array.isArray(r.amenities) ? r.amenities.join(", ") : r.amenities) : "Standard Workspace"
        };
      });

      // Format Bookings Sheet Data
      const bookingsRows = bookings.map((b: any) => {
        const slotsStr = Array.isArray(b.slots) ? b.slots.join(", ") : (b.slots || "");
        return {
          "Booking ID": b.id || "",
          "Space / Room": b.room || "",
          "Reservation Date": b.date || "",
          "Time Slot(s)": slotsStr,
          "Title / Purpose": b.title || "",
          "Organizer Name": b.organizer || "",
          "Organizer Role": b.role || "",
          "Color Tag": b.color || "red"
        };
      });

      // Format Members / Personas Sheet Data
      const personasRows = personas.map((p: any) => ({
        "Member Name": p.name || "",
        "Role / Department": p.role || "",
        "Email Address": p.email || "",
        "Security PIN Protected": p.pin ? "Yes (Protected)" : "No"
      }));

      // Format Summary Stats Sheet Data
      const pendingCount = requests.filter((r: any) => r.status === "Pending").length;
      const approvedCount = requests.filter((r: any) => r.status === "Approved").length;
      const rejectedCount = requests.filter((r: any) => r.status === "Rejected").length;
      const queriedCount = requests.filter((r: any) => r.status === "Queried").length;

      const summaryRows = [
        { "Metric": "Total Booking Requests Submitted", "Value": requests.length },
        { "Metric": "Pending Approvals", "Value": pendingCount },
        { "Metric": "Approved Requests", "Value": approvedCount },
        { "Metric": "Clarification Queried Requests", "Value": queriedCount },
        { "Metric": "Rejected Requests", "Value": rejectedCount },
        { "Metric": "Active Confirmed Bookings", "Value": bookings.length },
        { "Metric": "Registered Members / Profiles", "Value": personas.length },
        { "Metric": "Last Ledger Update Timestamp (IST)", "Value": new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" }) }
      ];

      // Create Workbook
      const workbook = XLSX.utils.book_new();

      const wsRequests = XLSX.utils.json_to_sheet(requestsRows.length > 0 ? requestsRows : [{ "Status": "No booking requests yet" }]);
      const wsBookings = XLSX.utils.json_to_sheet(bookingsRows.length > 0 ? bookingsRows : [{ "Status": "No confirmed bookings yet" }]);
      const wsPersonas = XLSX.utils.json_to_sheet(personasRows.length > 0 ? personasRows : [{ "Status": "No members registered yet" }]);
      const wsSummary = XLSX.utils.json_to_sheet(summaryRows);

      // Auto-fit column widths
      [wsRequests, wsBookings, wsPersonas, wsSummary].forEach(ws => {
        const range = XLSX.utils.decode_range(ws["!ref"] || "A1:A1");
        const colWidths = [];
        for (let C = range.s.c; C <= range.e.c; ++C) {
          colWidths.push({ wch: 22 });
        }
        ws["!cols"] = colWidths;
      });

      XLSX.utils.book_append_sheet(workbook, wsRequests, "Booking Requests");
      XLSX.utils.book_append_sheet(workbook, wsBookings, "Confirmed Bookings");
      XLSX.utils.book_append_sheet(workbook, wsPersonas, "Members & Personas");
      XLSX.utils.book_append_sheet(workbook, wsSummary, "Summary & Metrics");

      // Write to disk
      XLSX.writeFile(workbook, EXCEL_FILE);
      console.log(`[Excel Service] Updated ledger at ${EXCEL_FILE}`);
    } catch (err) {
      console.error("[Excel Service] Error updating Excel ledger:", err);
    }
  }

  // Initial update on startup
  updateExcelLedger();

  // Get current shared state
  app.get("/api/state", (req, res) => {
    const bookings = readJSONFile(BOOKINGS_FILE);
    const requests = readJSONFile(REQUESTS_FILE);
    const personas = readJSONFile(PERSONAS_FILE);
    res.json({ bookings, requests, personas });
  });

  // Save bookings
  app.post("/api/state/bookings", (req, res) => {
    const { bookings } = req.body;
    writeJSONFile(BOOKINGS_FILE, bookings);
    updateExcelLedger();
    res.json({ success: true });
  });

  // Save requests
  app.post("/api/state/requests", (req, res) => {
    const { requests } = req.body;
    writeJSONFile(REQUESTS_FILE, requests);
    updateExcelLedger();
    res.json({ success: true });
  });

  // Save personas
  app.post("/api/state/personas", (req, res) => {
    const { personas } = req.body;
    writeJSONFile(PERSONAS_FILE, personas);
    updateExcelLedger();
    res.json({ success: true });
  });

  // Get Excel Status Info
  app.get("/api/state/excel-info", (req, res) => {
    try {
      const exists = fs.existsSync(EXCEL_FILE);
      let sizeBytes = 0;
      let mtime = null;
      if (exists) {
        const stats = fs.statSync(EXCEL_FILE);
        sizeBytes = stats.size;
        mtime = stats.mtime;
      }
      const requests = readJSONFile(REQUESTS_FILE) || [];
      const bookings = readJSONFile(BOOKINGS_FILE) || [];
      res.json({
        exists,
        sizeBytes,
        lastModified: mtime,
        totalRequests: requests.length,
        totalBookings: bookings.length,
        filename: "NIET_TBI_Booking_Ledger.xlsx"
      });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Download Excel Workbook (.xlsx)
  app.get("/api/export/excel", (req, res) => {
    try {
      updateExcelLedger();
      if (!fs.existsSync(EXCEL_FILE)) {
        return res.status(404).send("Excel ledger file not found.");
      }
      res.setHeader("Content-Disposition", 'attachment; filename="NIET_TBI_Booking_Ledger.xlsx"');
      res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
      const fileStream = fs.createReadStream(EXCEL_FILE);
      fileStream.pipe(res);
    } catch (err: any) {
      console.error("Export error:", err);
      res.status(500).send("Error exporting Excel file: " + err.message);
    }
  });

  // Download CSV Format
  app.get("/api/export/csv", (req, res) => {
    try {
      const requests = readJSONFile(REQUESTS_FILE) || [];
      const requestsRows = requests.map((r: any) => ({
        "Request ID": r.id || "",
        "Submission Time": r.timestamp ? new Date(r.timestamp).toISOString() : "",
        "Requester Name": r.requesterName || "",
        "Role": r.role || "",
        "Email": r.email || "",
        "Room": r.room || "",
        "Date": r.date || "",
        "Slots": Array.isArray(r.slots) ? r.slots.join("; ") : (r.slots || ""),
        "Purpose": r.purpose || "",
        "Status": r.status || "Pending"
      }));

      const ws = XLSX.utils.json_to_sheet(requestsRows.length > 0 ? requestsRows : [{ "Status": "No records" }]);
      const csv = XLSX.utils.sheet_to_csv(ws);

      res.setHeader("Content-Disposition", 'attachment; filename="NIET_TBI_Requests.csv"');
      res.setHeader("Content-Type", "text/csv; charset=utf-8");
      res.send(csv);
    } catch (err: any) {
      res.status(500).send("Error exporting CSV: " + err.message);
    }
  });

  // API Route to send email
  app.post("/api/notify", async (req, res) => {
    try {
      const { email, name, room, date, slots, status } = req.body;
      
      if (!email) {
        return res.status(400).json({ error: "Email is required" });
      }

      console.log(`[Email Service] Preparing notification for ${email} (${name}) - Status: ${status}`);

      // Setup standard transporter with environment variables
      const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST || "smtp.gmail.com",
        port: parseInt(process.env.SMTP_PORT || "587"),
        secure: process.env.SMTP_PORT === "465", // true for 465, false for other ports
        auth: {
          user: process.env.SMTP_USER || "",
          pass: process.env.SMTP_PASS || "",
        },
      });

      let subject = "";
      let htmlContent = "";

      const slotString = slots && Array.isArray(slots) ? slots.join(", ") : slots;

      if (status === "Pending") {
        subject = `Booking Request Submitted: ${room}`;
        htmlContent = `
          <div style="font-family: sans-serif; padding: 20px; border: 1px solid #e2e8f0; border-radius: 8px; max-width: 600px; margin: 0 auto; color: #334155;">
            <h2 style="color: #475569; border-bottom: 2px solid #ef4444; padding-bottom: 10px; font-weight: 800;">👋 Request Received</h2>
            <p>Hi <strong>${name}</strong>,</p>
            <p>Your incubator space booking request has been submitted and is currently <strong>awaiting approval</strong> from the Administrator.</p>
            <hr style="border: 0; border-top: 1px solid #e2e8f0; margin: 20px 0;" />
            <h3 style="color: #1e293b; margin-bottom: 5px;">Reservation Details:</h3>
            <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
              <tr style="background-color: #f8fafc;"><td style="padding: 8px; font-weight: bold; width: 120px;">Space:</td><td style="padding: 8px;">${room}</td></tr>
              <tr><td style="padding: 8px; font-weight: bold;">Date:</td><td style="padding: 8px;">${date}</td></tr>
              <tr style="background-color: #f8fafc;"><td style="padding: 8px; font-weight: bold;">Time Slot(s):</td><td style="padding: 8px;">${slotString}</td></tr>
            </table>
            <p style="font-size: 12px; color: #64748b; margin-top: 30px; text-align: center;">NIET Incubator Booking Portal. Please do not reply directly to this email.</p>
          </div>
        `;
      } else if (status === "Approved") {
        subject = `🎉 Booking APPROVED: ${room}`;
        htmlContent = `
          <div style="font-family: sans-serif; padding: 20px; border: 1px solid #e2e8f0; border-radius: 8px; max-width: 600px; margin: 0 auto; color: #334155;">
            <h2 style="color: #15803d; border-bottom: 2px solid #16a34a; padding-bottom: 10px; font-weight: 800;">🎉 Booking Approved!</h2>
            <p>Hi <strong>${name}</strong>,</p>
            <p>Great news! Your booking request for the incubator space has been <strong>Approved</strong> by the Superuser Administrator.</p>
            <hr style="border: 0; border-top: 1px solid #e2e8f0; margin: 20px 0;" />
            <h3 style="color: #1e293b; margin-bottom: 5px;">Reservation Details:</h3>
            <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
              <tr style="background-color: #f0fdf4;"><td style="padding: 8px; font-weight: bold; width: 120px;">Space:</td><td style="padding: 8px; color: #166534;">${room}</td></tr>
              <tr><td style="padding: 8px; font-weight: bold;">Date:</td><td style="padding: 8px;">${date}</td></tr>
              <tr style="background-color: #f0fdf4;"><td style="padding: 8px; font-weight: bold;">Time Slot(s):</td><td style="padding: 8px;">${slotString}</td></tr>
            </table>
            <p style="margin-top: 20px;">Your spot is officially reserved. Please make sure to arrive on time and adhere to the incubator space guidelines.</p>
            <p style="font-size: 12px; color: #64748b; margin-top: 30px; text-align: center;">NIET Incubator Booking Portal. Please do not reply directly to this email.</p>
          </div>
        `;
      } else if (status === "Rejected") {
        subject = `Booking Request Denied: ${room}`;
        htmlContent = `
          <div style="font-family: sans-serif; padding: 20px; border: 1px solid #e2e8f0; border-radius: 8px; max-width: 600px; margin: 0 auto; color: #334155;">
            <h2 style="color: #b91c1c; border-bottom: 2px solid #dc2626; padding-bottom: 10px; font-weight: 800;">❌ Booking Request Denied</h2>
            <p>Hi <strong>${name}</strong>,</p>
            <p>Unfortunately, your booking request for the incubator space has been <strong>Rejected</strong> by the Administrator. This might be due to scheduling conflicts, capacity constraints, or resource prioritization.</p>
            <hr style="border: 0; border-top: 1px solid #e2e8f0; margin: 20px 0;" />
            <h3 style="color: #1e293b; margin-bottom: 5px;">Requested Reservation Details:</h3>
            <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
              <tr style="background-color: #fef2f2;"><td style="padding: 8px; font-weight: bold; width: 120px;">Space:</td><td style="padding: 8px; color: #991b1b;">${room}</td></tr>
              <tr><td style="padding: 8px; font-weight: bold;">Date:</td><td style="padding: 8px;">${date}</td></tr>
              <tr style="background-color: #fef2f2;"><td style="padding: 8px; font-weight: bold;">Time Slot(s):</td><td style="padding: 8px;">${slotString}</td></tr>
            </table>
            <p style="margin-top: 20px;">We welcome you to submit a request for an alternate slot or day on the Booker Portal.</p>
            <p style="font-size: 12px; color: #64748b; margin-top: 30px; text-align: center;">NIET Incubator Booking Portal. Please do not reply directly to this email.</p>
          </div>
        `;
      } else if (status === "Queried") {
        subject = `ℹ️ Additional Details Requested: ${room}`;
        htmlContent = `
          <div style="font-family: sans-serif; padding: 20px; border: 1px solid #e2e8f0; border-radius: 8px; max-width: 600px; margin: 0 auto; color: #334155;">
            <h2 style="color: #6b21a8; border-bottom: 2px solid #8b5cf6; padding-bottom: 10px; font-weight: 800;">ℹ️ Clarification / Details Requested</h2>
            <p>Hi <strong>${name}</strong>,</p>
            <p>The Superuser Administrator is reviewing your booking request for the incubator space and has requested additional details or clarification regarding your meeting/purpose.</p>
            <hr style="border: 0; border-top: 1px solid #e2e8f0; margin: 20px 0;" />
            <h3 style="color: #1e293b; margin-bottom: 5px;">Reservation Under Review:</h3>
            <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
              <tr style="background-color: #f3e8ff;"><td style="padding: 8px; font-weight: bold; width: 120px;">Space:</td><td style="padding: 8px; color: #6b21a8;">${room}</td></tr>
              <tr><td style="padding: 8px; font-weight: bold;">Date:</td><td style="padding: 8px;">${date}</td></tr>
              <tr style="background-color: #f3e8ff;"><td style="padding: 8px; font-weight: bold;">Time Slot(s):</td><td style="padding: 8px;">${slotString}</td></tr>
            </table>
            <p style="margin-top: 20px; padding: 12px; background-color: #fcf6ff; border-left: 4px solid #a855f7; font-style: italic;">
              "Please check back with the incubation desk or the portal's status tracker. If needed, provide details to the TBI administrators directly."
            </p>
            <p style="font-size: 12px; color: #64748b; margin-top: 30px; text-align: center;">NIET Incubator Booking Portal. Please do not reply directly to this email.</p>
          </div>
        `;
      }

      // Check if SMTP is configured
      if (!process.env.SMTP_USER || !process.env.SMTP_PASS) {
        console.warn("[Email Service] SMTP configuration is missing. Logging email to terminal console for simulation:");
        console.log(`========================================`);
        console.log(`To: ${email}`);
        console.log(`Subject: ${subject}`);
        console.log(`Body:`);
        console.log(htmlContent.replace(/<[^>]*>/g, '').trim()); // Strip basic HTML tags for console
        console.log(`========================================`);

        return res.json({ 
          success: true, 
          simulated: true, 
          message: "Email simulated successfully in console. Setup your SMTP credentials in .env to send real emails." 
        });
      }

      await transporter.sendMail({
        from: process.env.SMTP_FROM || process.env.SMTP_USER,
        to: email,
        subject: subject,
        html: htmlContent
      });

      console.log(`[Email Service] Email sent successfully to ${email}`);
      res.json({ success: true, message: "Notification email sent successfully." });
    } catch (error: any) {
      console.error("[Email Service] Failed to send email:", error);
      res.status(500).json({ error: error.message || "Failed to send email" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
